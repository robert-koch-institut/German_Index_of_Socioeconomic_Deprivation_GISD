 # Revision 2020

The Reference Date for all Regional Definitions ("Gebietsstand") is 31.12.2017. The update includes data for Years 1998 to 2017.

