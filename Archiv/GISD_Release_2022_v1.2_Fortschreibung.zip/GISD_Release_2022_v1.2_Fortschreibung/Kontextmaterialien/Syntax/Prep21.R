# GISD - German Index of Socio-Economic Deprivation - Prep21
# Author: Lola Omar Soliman
# Citation: https://github.com/robert-koch-institut/German_Index_of_Socioeconomic_Deprivation_GISD

# Revision: 2024_s19_21_v1
# Date: 2024-07-25

# Parallel zur regulären Generierung des GISD 1998-2019 im Hauptskript wird hier 
# möglichst der selbe Prozess auf einen Datensatz mit erweiterter Zeitreihe angewendet.
# Am Ende werden die hinzugekommenen Datenjahre (die "Scheiben") exportiert,
# um im Hauptskript weiter verarbeitet zu werden.

# Libraries
library(tidyverse)
library(readxl)
library(haven)

# Scientific Notation in der Zahlendarstellung abschalten (Wichtig!)
options(scipen = 50)

## Skriptpfad als Arbeitspfad setzen
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

# Pfaddefinitionen
infiles_dir  <- "../Rohdaten/"

# Hinzugekommene Datenjahre und das neueste davon vermerken
zusatzjahre <- c(2020, 2021)
latestyear <- max(zusatzjahre)

# Zuordnung Bundesländer
bl_zuordnung <- tibble(gkz_prefix = c("01", "02", "03", "04", "05", "06", "07",
                                      "08", "09", "10", "11", "12", "13", "14", "15", "16"),
                       Bundesland = c("Schleswig-Holstein", "Hamburg", "Niedersachsen",
                                      "Bremen", "Nordrhein-Westfalen", "Hessen",
                                      "Rheinland-Pfalz", "Baden-Württemberg", "Bayern",
                                      "Saarland", "Berlin", "Brandenburg",
                                      "Mecklenburg-Vorpommern", "Sachsen",
                                      "Sachsen-Anhalt", "Thüringen"))

## I. Generierung eines ID-Datensatzes
# Info: Wir mussten die Gebiets-Referenzen bisher selber generieren,
# aber BBSR hat für ab 2021 vollständige Referenzen online verfügbar.
# (Quelle: https://www.bbsr.bund.de/BBSR/DE/forschung/raumbeobachtung/downloads/download-referenzen.html)
# Konsistenzhalber wird das Format der Referenz an das gewohnte Format angeglichen.
id_dataset_Scheibe <- read_excel(paste0(infiles_dir,
                                        "Referenz/raumgliederungen-referenzen-2022.xlsx"),
                                 sheet="Gemeindereferenz (inkl. Kreise)",
                                 na="NA") %>%
  slice(-1) %>% #Erste Zeile ist leer, kann raus
  mutate(gkz_prefix = substr(str_pad(GEM2022, width = 8, pad = "0"), 1, 2)) %>%
  left_join(bl_zuordnung, by = "gkz_prefix") %>%
  mutate("Gemeindekennziffer" = as.numeric(GEM2022),
         "Name der Gemeinde" = GEM_NAME,
         "GVBKennziffer" = as.numeric(VWG2022),
         "Bevoelkerung" = as.numeric(bev22)/100, #Bevölkerung muss in 100 angegeben werden (Wichtig!)
         "Kreiskennziffer" = as.numeric(str_sub(KRS2022, end = -4)),
         "Name des Kreises" = KRS_NAME,
         "Raumordnungsregion Nr" = as.numeric(KRO2022),
         "Raumordnungsregion" = KRO_NAME,
         "NUTS2" = N2D2022,
         "NUTS2 Name" = N2D_NAME,
         "Name des Gemeindeverbands" = VWG_NAME) %>% 
  select(Gemeindekennziffer, "Name der Gemeinde", GVBKennziffer, Bevoelkerung,
         Kreiskennziffer, "Name des Kreises", "Raumordnungsregion Nr", Raumordnungsregion,
         NUTS2, "NUTS2 Name", Bundesland, "Name des Gemeindeverbands")

Gemeinden_INKAR_Scheibe <- id_dataset_Scheibe %>%
  distinct(Gemeindekennziffer, .keep_all = TRUE) %>% 
  select(Kennziffer = Gemeindekennziffer,
         Kreis = Kreiskennziffer,
         GVBKennziffer,
         Bevoelkerung)

# Mit Basisdaten für Kreis anfangen
Basedata_Scheibe <- Gemeinden_INKAR_Scheibe %>% 
  distinct(Kreis) %>% 
  rename(Kennziffer = Kreis) %>% 
  mutate(Jahr = 2021)

# Inputliste der hinzuzufügenden Rohdaten erstellen
inputdataset <- list.files(paste0(infiles_dir, "INKAR_1998_",latestyear)) %>%
  .[str_detect(., "\\.xls(x)?$")] # Alle Excel Files im Ordner auflisten

  # Die pre-2012-Daten werden gleich nachher seperat verarbeitet und müssen deshalb aus der Liste raus
  inputdataset <- inputdataset[!inputdataset %in% "B_BeschaeftigteohneAbschluss_pre2012.xlsx"]
  inputdataset <- inputdataset[!inputdataset %in% "B_BeschaeftigtemitakadAbschluss_pre2012.xlsx"]
  
for(file in inputdataset){
  myimport <- read_excel(paste0(infiles_dir,
                                "INKAR_1998_",latestyear,"/",
                                file),
                         skip = 1,
                         sheet = "Daten") %>%
    rename("Kennziffer" = ...1) %>% #Kennziffer-Spalte benennen
    select(-...2, -...3) #Irrelevante Spalten entfernen
  
  #Umwandeln von Wide zu Long - Das Jahr nun Zeilenweise statt Spaltenweise
  myimport <- myimport %>%
    gather(key = Jahr,
           value = Value,
           -Kennziffer,
           convert = TRUE,
           na.rm = TRUE) %>%
    mutate(Kennziffer = as.numeric(as.character(Kennziffer)),
           Value = as.numeric(Value)) %>% 
    filter(Jahr <= latestyear) #Sicherheitshalber noch mal Jahre filtern
  
  # Setze Dateinamen des jeweiligen Indikators als Variablennamen ein
  names(myimport)[3] <- strsplit(strsplit(file,"_")[[1]][2],"[.]")[[1]][1]
  
  # Zu Basedata hinzufügen
  Basedata_Scheibe <- full_join(Basedata_Scheibe, myimport, by=c("Kennziffer", "Jahr"))
}

# Ergänzung der Beschäftigtenqualifikationen vor 2012 anhand alter Rohdaten
pre2012_ohneAbschluss <- read_excel(paste0(infiles_dir,
                                        "INKAR_1998_",latestyear,
                                        "/B_BeschaeftigteohneAbschluss_pre2012.xlsx"),
                                 skip = 1,
                                 sheet = "Daten") %>% 
  rename("Kreis" = `...1`) %>% # Kennziffer benennen
  select(-`...2`, -`...3`) %>% # Leere Spalten entfernen
  #Umwandeln von Wide zu Long - Das Jahr nun Zeilenweise statt Spaltenweise
  gather(key = Jahr,
         value = ohneAbschluss,
         -Kreis,
         convert = TRUE,
         na.rm = TRUE) %>%
  mutate(Kreis = as.numeric(as.character(Kreis)),
         ohneAbschluss = as.numeric(ohneAbschluss)) %>% 
  filter(Jahr <= 2011)

pre2012_akadAbschluss <- read_excel(paste0(infiles_dir,
                                        "INKAR_1998_",latestyear,
                                        "/B_BeschaeftigtemitakadAbschluss_pre2012.xlsx"),
                                 skip = 1,
                                 sheet = "Daten") %>% 
  rename("Kreis" = `...1`) %>% # Kennziffer benennen
  select(-`...2`, -`...3`) %>% # Leere Spalten entfernen
  #Umwandeln von Wide zu Long - Das Jahr nun Zeilenweise statt Spaltenweise
  gather(key = Jahr,
         value = akadAbschluss,
         -Kreis,
         convert = TRUE,
         na.rm = TRUE) %>%
  mutate(Kreis = as.numeric(as.character(Kreis)),
         akadAbschluss = as.numeric(akadAbschluss)) %>% 
  filter(Jahr <= 2011)

pre2012_svbesch <- read_excel(paste0(infiles_dir,
                             "INKAR_1998_",latestyear,
                             "/B_SVBeschaeftigte.xls"),
                      skip = 1,
                      sheet = "Daten") %>% 
  rename("Kreis" = `...1`) %>% # Kennziffer benennen
  select(-`...2`, -`...3`) %>% # Leere Spalten entfernen
  #Umwandeln von Wide zu Long - Das Jahr nun Zeilenweise statt Spaltenweise
  gather(key = Jahr,
         value = svbesch,
         -Kreis,
         convert = TRUE,
         na.rm = TRUE) %>%
  mutate(Kreis = as.numeric(as.character(Kreis)),
         svbesch = as.numeric(svbesch)) %>%
  filter(Jahr <= 2011)

pre2012_beschq <- left_join(pre2012_ohneAbschluss, pre2012_akadAbschluss,
                            by = c("Kreis", "Jahr")) %>% 
  left_join(pre2012_svbesch, by = c("Kreis", "Jahr")) %>% 
  mutate(akadAbschluss = akadAbschluss / svbesch * 100,
         ohneAbschluss = ohneAbschluss / svbesch * 100,
         Kennziffer = Kreis)

Basedata_Scheibe <- Basedata_Scheibe %>% 
  left_join(pre2012_beschq, by = c("Kennziffer", "Jahr")) %>% 
  mutate(BeschaeftigtemitakadAbschluss = ifelse(Jahr <= 2011, akadAbschluss, BeschaeftigtemitakadAbschluss),
         BeschaeftigteohneAbschluss = ifelse(Jahr <= 2011, ohneAbschluss, BeschaeftigteohneAbschluss)) %>% 
  select(-ohneAbschluss, -akadAbschluss, -svbesch, -Kreis)

rm(pre2012_akadAbschluss, pre2012_ohneAbschluss, pre2012_svbesch, pre2012_beschq,
   bl_zuordnung)
  
# Weiter wie gewohnt
level_table <- data.frame(Indikator=names(Basedata_Scheibe)[-(1:2)],
                          Tiefe_Indikator=c("Gemeindeverband", "Gemeindeverband",
                                            "Kreis", "Gemeindeverband",
                                            "Kreis", "Kreis", "Kreis", "Kreis", "Kreis",
                                            "Gemeindeverband", "Kreis", "Kreis"))
  
Indikatoren_Gemeindeverband <- level_table %>%
  filter(Tiefe_Indikator == "Gemeindeverband") %>%
  pull(Indikator)

Indikatoren_Kreis <- level_table %>%
  filter(Tiefe_Indikator == "Kreis") %>%
  pull(Indikator)

Basedata_Scheibe_Gemeindeverbandsebene <- Basedata_Scheibe %>%
  select(Gemeindeverband=Kennziffer,
         Jahr, all_of(Indikatoren_Gemeindeverband)) %>%   
  gather(key, value, 3:5) %>%
  filter(!is.na(value)) %>%
  spread(key, value) %>%
  filter(Jahr>=1998)

Basedata_Scheibe_Kreisebene <- Basedata_Scheibe %>%
  select(Kreis=Kennziffer,
         Jahr,
         all_of(Indikatoren_Kreis)) %>% 
  filter(Jahr>=1998)
  
Workfile_Scheibe <- expand.grid(Kennziffer=Gemeinden_INKAR_Scheibe$Kennziffer,
                        Jahr=sort(unique(Basedata_Scheibe$Jahr))) %>%
  mutate(Kreiskennziffer=floor(as.numeric(Kennziffer)/1000)) %>%
  as_tibble() %>%
  left_join(Gemeinden_INKAR_Scheibe, by="Kennziffer") %>%
  select(Gemeindekennziffer=Kennziffer,
         Kreis=Kreiskennziffer,
         Gemeindeverband=GVBKennziffer,
           Jahr,
         Bevoelkerung) %>%
  mutate(Gemeindeverband=as.numeric(Gemeindeverband),
         Bevoelkerung=as.numeric(Bevoelkerung)) %>% 
  arrange(Gemeindeverband, Jahr) %>% # Join Metadata
  left_join(Basedata_Scheibe_Kreisebene, by=c("Kreis", "Jahr")) %>%
  left_join(Basedata_Scheibe_Gemeindeverbandsebene, by=c("Gemeindeverband", "Jahr")) %>%
  filter(Jahr >= 1998)
  
inputdataset_kreis <- list.files(paste0(infiles_dir, "INKAR_1998_",latestyear,"/Indikatoren_Kreisebene/"))

for(file in inputdataset_kreis) {
  myimport <- read_excel(paste0(infiles_dir,
                                "INKAR_1998_",latestyear,"/Indikatoren_Kreisebene/",
                                file),
                         skip = 1, sheet = "Daten") %>%
    rename("Kreis" = ...1) %>% #Kennziffer markieren
    select(-...2, -...3) #Irrelevante Spalten entfernen
  
  #Umwandeln von Wide zu Long - Das Jahr nun Zeilenweise statt Spaltenweise
  myimport <- myimport %>%
    gather(key=Jahr,
           value=Value,
           -Kreis,
           convert=TRUE,
           na.rm=TRUE) %>%
    mutate(Kreis=as.numeric(as.character(Kreis)),
           Value=as.numeric(Value)) %>% 
    filter(Jahr <= latestyear) #Sicherheitshalber noch mal Jahre filtern
  
  #Setze Dateinamen des jeweiligen Indikators als Variablenname ein
  names(myimport)[names(myimport) == "Value"] <- gsub("^.+_(.+)[.].+$", #Alles zw. Leerstrich und Punkt
                                                      "\\1", #Detected String einsetzen
                                                      file) #Aus current File-String
  
  Workfile_Scheibe <- Workfile_Scheibe %>%
    full_join(myimport, by=c("Kreis", "Jahr"))
}

Workfile_Scheibe <- Workfile_Scheibe %>%
  mutate(ErwerbsfaehigeBevoelkerung=ifelse(Jahr < 2001, ErwerbsfaehigeBevoelkerungKreis, ErwerbsfaehigeBevoelkerung),
         Arbeitslosigkeit          =ifelse(Jahr < 2001, ArbeitslosigkeitKreis,           Arbeitslosigkeit),
         Beschaeftigtenquote       =ifelse(Jahr < 2001, BeschaeftigtenquoteKreis,        Beschaeftigtenquote)) %>%
  select(-ErwerbsfaehigeBevoelkerungKreis,
         -ArbeitslosigkeitKreis,
         -BeschaeftigtenquoteKreis)

Workfile_Scheibe <- Workfile_Scheibe %>%
  filter(Bevoelkerung > 0) %>%
  mutate(Arbeitslosigkeit=round(Arbeitslosigkeit / ErwerbsfaehigeBevoelkerung * 1000, digits=2),
         Arbeitslosigkeit=ifelse(is.finite(Arbeitslosigkeit),
                                 Arbeitslosigkeit, NA)) %>%
  select(-SVBeschaeftigte, -ErwerbsfaehigeBevoelkerung)

rm(myimport, level_table, file, Indikatoren_Gemeindeverband, Indikatoren_Kreis,
   inputdataset, inputdataset_kreis)

# Adjustierungen für die zusätzlichen Jahre, mit möglichst den selben Gewichten
# wie damals für den 19er Release. Aufgrund des veränderten Gebietsstands leider
# nicht 100% identisch. Zusätzlich kommt 2020 als erstes G9-Jahr dazu, das muss in der
# Regression berücksichtigt werden. Die Datenbasis für die Regression der
# Ost-West-Adjustierung wird auf <= 2019 beschränkt. Wir überspringen die
# Adjustierung für die Messänderung 2012, weil wir nur die Jahre ab 2020 brauchen.
Verbraucherpreisindex <- data.frame(Jahr   =seq(1998, 2021),
                                    VBindex=c( 78.3,  78.8,
                                               79.9,  81.5,  82.6,  83.5,  84.9,
                                               86.2,  87.6,  89.6,  91.9,  92.2,
                                               93.2,  95.2,  97.1,  98.5,  99.5, 
                                               100,  100.5,  102,  103.8, 105.3,
                                               105.8, 109.1))

Workfile_full <- Workfile_Scheibe %>%
  left_join(Verbraucherpreisindex, by="Jahr") %>%
  mutate(Einkommensteuer   =Einkommensteuer    / VBindex * 100,
         Haushaltseinkommen=Haushaltseinkommen / VBindex * 100,
         Bruttoverdienst   =Bruttoverdienst    / VBindex * 100,
         Einkommensteuer_ln   =ifelse(Einkommensteuer == 0, 0.75, log(Einkommensteuer)),
         Haushaltseinkommen_ln=log(Haushaltseinkommen),
         Bruttoverdienst_ln   =log(Bruttoverdienst),
         G8_jahr=case_when(Kreis < 2000  &                 Jahr == 2016 ~ 1,
                           Kreis > 1999  & Kreis < 3000  & Jahr == 2010 ~ 1,
                           Kreis > 2999  & Kreis < 4000  & Jahr == 2011 ~ 1,
                           Kreis > 3999  & Kreis < 5000  & Jahr == 2012 ~ 1,
                           Kreis > 4999  & Kreis < 6000  & Jahr == 2013 ~ 1,
                           Kreis > 5999  & Kreis < 7000  & Jahr == 2013 ~ 1,
                           Kreis > 7999  & Kreis < 9000  & Jahr == 2012 ~ 1,
                           Kreis > 8999  & Kreis < 10000 & Jahr == 2011 ~ 1,
                           Kreis > 9999  & Kreis < 11000 & Jahr == 2009 ~ 1,
                           Kreis > 10999 & Kreis < 12000 & Jahr == 2012 ~ 1,
                           Kreis > 11999 & Kreis < 13000 & Jahr == 2012 ~ 1,
                           Kreis > 12999 & Kreis < 14000 & Jahr == 2008 ~ 1,
                           Kreis > 14999 & Kreis < 16000 & Jahr == 2007 ~ 1,
                           TRUE ~ 0),
         G9_jahr=case_when(Kreis > 7999 & Kreis < 9000 & Jahr == 2020 ~ 1,
                           TRUE ~ 0),
         SN_KA       =ifelse(Kreis > 14999 & Kreis < 16000 & Jahr == 2001, 1, 0),
         THvor2004   =ifelse(Kreis > 15999                 & Jahr <  2004, 1, 0))

# Funktion für G8/G9-Ausgleich
adj_G8_jahr <- function(data, outcome_name) {
  mydata <- data %>%
    group_by(Gemeindekennziffer) %>% 
    select(Gemeindekennziffer, Jahr,
           G8_jahr, G9_jahr, SN_KA, THvor2004,
           Outcome=all_of(outcome_name)) %>%
    mutate(MEAN=mean(Outcome, na.rm=TRUE)) %>%
    ungroup()
  
  mymodell2 <- lm(Outcome ~
                    I(Jahr*Jahr*MEAN) + I(Jahr*MEAN) + G8_jahr + G9_jahr + SN_KA + THvor2004,
                  data=mydata, na.action="na.exclude")
  
  print(mymodell2)
  
  mydata %>%
    mutate(coef_G8=coef(mymodell2)["G8_jahr"],
           coef_G9=coef(mymodell2)["G9_jahr"],
           coef_SH=coef(mymodell2)["SN_KA"],
           coef_TH=coef(mymodell2)["THvor2004"],
           Outcome=ifelse(G8_jahr   == 1, Outcome - coef_G8, Outcome),
           Outcome=ifelse(G9_jahr   == 1, Outcome - coef_G9, Outcome),
           Outcome=ifelse(SN_KA     == 1, Outcome - coef_SH, Outcome),
           Outcome=ifelse(THvor2004 == 1, Outcome - coef_TH, Outcome)) %>%
    pull(Outcome)
}

# Funktion für Ostwest-Ausgleich
OW <- function(data,outcome_name){
  mydata <- data %>%
    select(Gemeindekennziffer, Jahr, OW,
           Outcome=all_of(outcome_name)) %>% 
    mutate(Jahr_Dummy=relevel(as.factor(Jahr), ref="2012")) %>%
    ungroup()
  
  mymodell_ow <- lm(Outcome ~ Jahr_Dummy + Jahr_Dummy*OW,
                    data= mydata%>%filter(Jahr <= 2019), #Datenbasis beschränken, um die Gewichte zu behalten
                    na.action="na.exclude")
  
  print(mymodell_ow)
  coef(mymodell_ow)["OW"]
  mydata %>%
    mutate(coef_ow=coef(mymodell_ow)["OW"]) %>%
    mutate(Outcome=ifelse(OW == 1, Outcome - coef_ow, Outcome)) %>%
    pull(Outcome)
}

# Anwenden der Adjustierungen
# Reminder: BeschaeftigtemitakadAbschluss würde normalerweise noch bzgl. Messänderung adjustiert werden.
# Das ist für Jahre nach 2012 nicht notwendig, aber wir benennen konsistenzhalber trotzdem auf "adjusted" um.
Workfile_full <- Workfile_full %>%
  mutate(SchulabgaengermitHochschulreife_adj=adj_G8_jahr(., "SchulabgaengermitHochschulreife"),
         SchulabgaengerohneAbschluss_adj    =adj_G8_jahr(., "SchulabgaengerohneAbschluss"),
         OW=ifelse(Kreis < 11000, 0, 1)) %>%
  mutate(BeschaeftigteohneAbschluss_adj=OW(., "BeschaeftigteohneAbschluss"),
         BeschaeftigtemitakadAbschluss_adj=BeschaeftigtemitakadAbschluss)


## Imputation zum Füllen von Datenlücken

# INKAR's Zeitreihen sind nicht immer vollständig.
# (z.B. Arbeitslosigkeit 2020 in Greußen, Stadt (160650089))
# Daher wenden wir eine multiple Imputation an, welche durch alle
# non-missing Einträge der Indikatoren informiert wird. (Stimmt das?)

# Datenlücken-Check vorher
lücken_vorher <- Workfile_full %>% 
  filter(Jahr >= 2004,
         is.na(Beschaeftigtenquote) |
           is.na(Arbeitslosigkeit) |
           is.na(Bruttoverdienst_ln) |
           is.na(Einkommensteuer_ln) |
           is.na(Haushaltseinkommen_ln) |
           is.na(Schuldnerquote) |
           is.na(BeschaeftigtemitakadAbschluss_adj) |
           is.na(BeschaeftigteohneAbschluss_adj) |
           is.na(SchulabgaengerohneAbschluss_adj)) %>% 
  select(Gemeindekennziffer, Gemeindeverband, Kreis,
         Jahr,
         Beschaeftigtenquote,
         Arbeitslosigkeit,
         Bruttoverdienst_ln,
         Einkommensteuer_ln,
         Haushaltseinkommen_ln,
         Schuldnerquote,
         BeschaeftigtemitakadAbschluss_adj,
         BeschaeftigteohneAbschluss_adj,
         SchulabgaengerohneAbschluss_adj)

# Aufbereitung
Impdata_Scheibe <- Workfile_full %>%
  filter(Jahr >= 1998) %>% 
  gather(key,value,6:15) %>%
  mutate(value=ifelse(value<0.00001,NA,value)) %>%
  spread(key,value)

## Index 6 bis 15:
## "Bruttoverdienst"                 "BeschaeftigteohneAbschluss"     
## "SchulabgaengermitHochschulreife" "SchulabgaengerohneAbschluss"    
## "Haushaltseinkommen"              "Schuldnerquote"                 
## "Einkommensteuer"                 "Arbeitslosigkeit"               
## "Beschaeftigtenquote"             "VBindex"

my_ts_imputer <- function(data,outcome_name) {
  mydata <- data %>%
    group_by(Gemeindekennziffer) %>%
    select(Gemeindekennziffer, Jahr,
           Outcome=all_of(outcome_name)) %>% 
    mutate(MEAN=mean(Outcome, na.rm=TRUE)) %>%
    ungroup()
  
  mymodell <- lm(Outcome ~
                   I(Jahr*Jahr*MEAN) + I(Jahr*MEAN),
                 data=mydata, na.action="na.exclude")
  
  mydata %>%
    mutate(Imputed=predict(mymodell, newdata=.)) %>%
    mutate(Outcome=ifelse(is.finite(Outcome), Outcome, Imputed),
           Outcome=ifelse(Outcome < 0, 0, Outcome)) %>%
    pull(Outcome)
}

Workfile_full <- Impdata_Scheibe %>%
  mutate(Arbeitslosigkeit                 =my_ts_imputer(., "Arbeitslosigkeit"),
         SchulabgaengerohneAbschluss_adj  =my_ts_imputer(., "SchulabgaengerohneAbschluss_adj"),
         SchulabgaengerohneAbschluss      =my_ts_imputer(., "SchulabgaengerohneAbschluss"),
         Beschaeftigtenquote              =my_ts_imputer(., "Beschaeftigtenquote"),
         Bruttoverdienst_ln               =my_ts_imputer(., "Bruttoverdienst_ln"),
         Bruttoverdienst                  =my_ts_imputer(., "Bruttoverdienst"),
         BeschaeftigtemitakadAbschluss_adj=my_ts_imputer(., "BeschaeftigtemitakadAbschluss_adj"),
         BeschaeftigtemitakadAbschluss    =my_ts_imputer(., "BeschaeftigtemitakadAbschluss"),
         BeschaeftigteohneAbschluss_adj   =my_ts_imputer(., "BeschaeftigteohneAbschluss_adj"),
         BeschaeftigteohneAbschluss       =my_ts_imputer(., "BeschaeftigteohneAbschluss"),
         Einkommensteuer_ln               =my_ts_imputer(., "Einkommensteuer_ln"),
         Einkommensteuer                  =my_ts_imputer(., "Einkommensteuer"),
         Haushaltseinkommen_ln            =my_ts_imputer(., "Haushaltseinkommen_ln"),
         Haushaltseinkommen               =my_ts_imputer(., "Haushaltseinkommen"),
         Schuldnerquote                   =my_ts_imputer(., "Schuldnerquote"))

# Datenlücken-Check nachher
lücken_nachher <- Workfile_full %>% 
  filter(Jahr >= 2004,
         is.na(Beschaeftigtenquote)  |
           is.na(Arbeitslosigkeit)   |
           is.na(Bruttoverdienst_ln) |
           is.na(Einkommensteuer_ln)    |
           is.na(Haushaltseinkommen_ln) |
           is.na(Schuldnerquote) |
           is.na(BeschaeftigtemitakadAbschluss_adj) |
           is.na(BeschaeftigteohneAbschluss_adj) |
           is.na(SchulabgaengerohneAbschluss_adj)) %>% 
  select(Gemeindekennziffer, Gemeindeverband, Kreis,
         Jahr,
         Beschaeftigtenquote,
         Arbeitslosigkeit,
         Bruttoverdienst_ln,
         Einkommensteuer_ln,
         Haushaltseinkommen_ln,
         Schuldnerquote,
         BeschaeftigtemitakadAbschluss_adj,
         BeschaeftigteohneAbschluss_adj,
         SchulabgaengerohneAbschluss_adj)

# Imputationscheck auf Arbeitslosigkeit 2020 in Greußen, Stadt (160650089) 
Imptest <- Workfile_full %>% 
  filter(Jahr >= 2019,
         Gemeindeverband == 160650089) %>%
  select(Gemeindeverband, Jahr, Arbeitslosigkeit)

# Sieht gut aus
rm(Imptest, lücken_vorher, lücken_nachher, my_ts_imputer, Impdata_Scheibe)

# Wir brauchen nur noch die Zeitreihenerweiterung, alles vor 2020 wird entfernt
# Zusätzlich bringen wir den Kreisstand von Eisenach manuell zurück auf 2019
Workfile_Scheibe <- Workfile_full %>%
  filter(Jahr %in% zusatzjahre) %>% 
  mutate(Kreis = if_else(Gemeindekennziffer == 16063105, 16056, Kreis))

## Umstellen des Gebietsstands
# Reminder: Gebietsstand ist der Zeitpunkt des Downloads, hier 2022.
# Nach dem Prinzip der Scheiben müssen wir die Daten auf Gebietsstand 2019 bringen.
# Daher brauchen wir jährliche Umsteigeschlüssel, über die wir die einzelnen Indikatoren anpassen können.
# (Je nach Indikator wird entweder gewichtet aufsummiert oder das gewichtete geometrische Mittel gebildet)

# Weighted Geometric Mean Funktion
# (Danke an https://stackoverflow.com/questions/49944192/calculate-weighted-geometric-average-in-r)
weighted.geomean <- function(x, w, ...) {
  return(prod(x^w, ...)^(1/sum(w)))
}

## Umsteigeschlüssel laden
## Quelle: https://www.bbsr.bund.de/BBSR/DE/forschung/raumbeobachtung/umstiegsschluessel/umsteigeschluessel.html

# Umsteigeschlüssel 19-20
# (Reminder: Wir steigen "rückwärts" um, von 2020 auf 2019, von gkz_neu auf gkz_alt)
umsteig19 <- read_excel("../Rohdaten/Referenz/ref-gemeinden-2010-2020.xlsx",
                      sheet = "2019-2020") %>%
  select(gkz_alt = `Gemeinden\r\n 31.12.2019`,
         gkz_neu = `Gemeinden\r\n 31.12.2020`,
         name_alt = `Gemeindename 2019`,
         name_neu = `Gemeindename 2020`,
         bpu = `bevölkerungs- \r\nproportionaler \r\nUmsteige- \r\nschlüssel`)

# Umsteigeschlüssel 20-21
umsteig20 <- read_excel("../Rohdaten/Referenz/ref-gemeinden-ab-2020.xlsx",
                        sheet = "2020") %>%
  select(gkz_alt = `Gemeinden\r\n 31.12.2020`,
         gkz_neu = `Gemeinden\r\n 31.12.2021`,
         name_alt = `Gemeindename 2020`,
         name_neu = `Gemeindename 2021`,
         bpu = `bevölkerungs- \r\nproportionaler \r\nUmsteige- \r\nschlüssel`)

# Umsteigeschlüssel 21-22
umsteig21 <- read_excel("../Rohdaten/Referenz/ref-gemeinden-ab-2020.xlsx",
                        sheet = "2021") %>%
  select(gkz_alt = `Gemeinden\r\n 31.12.2021`,
         gkz_neu = `Gemeinden\r\n 31.12.2022`,
         name_alt = `Gemeindename 2021`,
         name_neu = `Gemeindename 2022`,
         bpu = `bevölkerungs- \r\nproportionaler \r\nUmsteige- \r\nschlüssel`)

## Wir werden nun jedes Datenjahr aus unserer Zeitreihe EINZELN
## von Gebietsstand 2022 auf 2021 auf 2020 auf 2019 bringen
## und dann wieder zusammenlegen

#2020
Daten2020 <- Workfile_Scheibe %>% 
  filter(Jahr == 2020) %>% 
  left_join(., umsteig21, by = c("Gemeindekennziffer" = "gkz_neu")) %>%
  mutate(bev_anteil = Bevoelkerung * bpu) %>% 
  group_by(gkz_alt) %>%
  summarise(Kreis                             = first(Kreis),
            Gemeindeverband                   = first(Gemeindeverband),
            Jahr                              = first(Jahr),
            Bevoelkerung                      = sum(bev_anteil, na.rm = TRUE),
            Beschaeftigtenquote               = weighted.geomean(Beschaeftigtenquote, bpu),
            Arbeitslosigkeit                  = weighted.geomean(Arbeitslosigkeit, bpu),
            Bruttoverdienst_ln                = weighted.mean(Bruttoverdienst_ln, bpu),
            Einkommensteuer_ln                = weighted.mean(Einkommensteuer_ln, bpu),
            Haushaltseinkommen_ln             = weighted.mean(Haushaltseinkommen_ln, bpu),
            Schuldnerquote                    = weighted.geomean(Schuldnerquote, bpu),
            BeschaeftigtemitakadAbschluss_adj = weighted.geomean(BeschaeftigtemitakadAbschluss_adj, bpu),
            BeschaeftigteohneAbschluss_adj    = weighted.geomean(BeschaeftigteohneAbschluss_adj, bpu),
            SchulabgaengerohneAbschluss_adj   = weighted.geomean(SchulabgaengerohneAbschluss_adj, bpu)) %>% 
  rename(Gemeindekennziffer = gkz_alt) %>%  
  left_join(., umsteig20, by = c("Gemeindekennziffer" = "gkz_neu")) %>%
  mutate(bev_anteil = Bevoelkerung * bpu) %>% 
  group_by(gkz_alt) %>%
  summarise(Kreis                             = first(Kreis),
            Gemeindeverband                   = first(Gemeindeverband),
            Jahr                              = first(Jahr),
            Bevoelkerung                      = sum(bev_anteil, na.rm = TRUE),
            Beschaeftigtenquote               = weighted.geomean(Beschaeftigtenquote, bpu),
            Arbeitslosigkeit                  = weighted.geomean(Arbeitslosigkeit, bpu),
            Bruttoverdienst_ln                = weighted.mean(Bruttoverdienst_ln, bpu),
            Einkommensteuer_ln                = weighted.mean(Einkommensteuer_ln, bpu),
            Haushaltseinkommen_ln             = weighted.mean(Haushaltseinkommen_ln, bpu),
            Schuldnerquote                    = weighted.geomean(Schuldnerquote, bpu),
            BeschaeftigtemitakadAbschluss_adj = weighted.geomean(BeschaeftigtemitakadAbschluss_adj, bpu),
            BeschaeftigteohneAbschluss_adj    = weighted.geomean(BeschaeftigteohneAbschluss_adj, bpu),
            SchulabgaengerohneAbschluss_adj   = weighted.geomean(SchulabgaengerohneAbschluss_adj, bpu)) %>% 
  rename(Gemeindekennziffer = gkz_alt) %>% 
  left_join(., umsteig19, by = c("Gemeindekennziffer" = "gkz_neu")) %>%
  mutate(bev_anteil = Bevoelkerung * bpu) %>% 
  group_by(gkz_alt) %>%
  summarise(Kreis                             = first(Kreis),
            Gemeindeverband                   = first(Gemeindeverband),
            Jahr                              = first(Jahr),
            Bevoelkerung                      = sum(bev_anteil, na.rm = TRUE),
            Beschaeftigtenquote               = weighted.geomean(Beschaeftigtenquote, bpu),
            Arbeitslosigkeit                  = weighted.geomean(Arbeitslosigkeit, bpu),
            Bruttoverdienst_ln                = weighted.mean(Bruttoverdienst_ln, bpu),
            Einkommensteuer_ln                = weighted.mean(Einkommensteuer_ln, bpu),
            Haushaltseinkommen_ln             = weighted.mean(Haushaltseinkommen_ln, bpu),
            Schuldnerquote                    = weighted.geomean(Schuldnerquote, bpu),
            BeschaeftigtemitakadAbschluss_adj = weighted.geomean(BeschaeftigtemitakadAbschluss_adj, bpu),
            BeschaeftigteohneAbschluss_adj    = weighted.geomean(BeschaeftigteohneAbschluss_adj, bpu),
            SchulabgaengerohneAbschluss_adj   = weighted.geomean(SchulabgaengerohneAbschluss_adj, bpu)) %>% 
  rename(Gemeindekennziffer = gkz_alt)

#2021
Daten2021 <- Workfile_Scheibe %>% 
  filter(Jahr == 2021) %>% 
  left_join(., umsteig21, by = c("Gemeindekennziffer" = "gkz_neu")) %>%
  mutate(bev_anteil = Bevoelkerung * bpu) %>% 
  group_by(gkz_alt) %>%
  summarise(Kreis                             = first(Kreis),
            Gemeindeverband                   = first(Gemeindeverband),
            Jahr                              = first(Jahr),
            Bevoelkerung                      = sum(bev_anteil, na.rm = TRUE),
            Beschaeftigtenquote               = weighted.geomean(Beschaeftigtenquote, bpu),
            Arbeitslosigkeit                  = weighted.geomean(Arbeitslosigkeit, bpu),
            Bruttoverdienst_ln                = weighted.mean(Bruttoverdienst_ln, bpu),
            Einkommensteuer_ln                = weighted.mean(Einkommensteuer_ln, bpu),
            Haushaltseinkommen_ln             = weighted.mean(Haushaltseinkommen_ln, bpu),
            Schuldnerquote                    = weighted.geomean(Schuldnerquote, bpu),
            BeschaeftigtemitakadAbschluss_adj = weighted.geomean(BeschaeftigtemitakadAbschluss_adj, bpu),
            BeschaeftigteohneAbschluss_adj    = weighted.geomean(BeschaeftigteohneAbschluss_adj, bpu),
            SchulabgaengerohneAbschluss_adj   = weighted.geomean(SchulabgaengerohneAbschluss_adj, bpu)) %>% 
  rename(Gemeindekennziffer = gkz_alt) %>%  
  left_join(., umsteig20, by = c("Gemeindekennziffer" = "gkz_neu")) %>%
  mutate(bev_anteil = Bevoelkerung * bpu) %>% 
  group_by(gkz_alt) %>%
  summarise(Kreis                             = first(Kreis),
            Gemeindeverband                   = first(Gemeindeverband),
            Jahr                              = first(Jahr),
            Bevoelkerung                      = sum(bev_anteil, na.rm = TRUE),
            Beschaeftigtenquote               = weighted.geomean(Beschaeftigtenquote, bpu),
            Arbeitslosigkeit                  = weighted.geomean(Arbeitslosigkeit, bpu),
            Bruttoverdienst_ln                = weighted.mean(Bruttoverdienst_ln, bpu),
            Einkommensteuer_ln                = weighted.mean(Einkommensteuer_ln, bpu),
            Haushaltseinkommen_ln             = weighted.mean(Haushaltseinkommen_ln, bpu),
            Schuldnerquote                    = weighted.geomean(Schuldnerquote, bpu),
            BeschaeftigtemitakadAbschluss_adj = weighted.geomean(BeschaeftigtemitakadAbschluss_adj, bpu),
            BeschaeftigteohneAbschluss_adj    = weighted.geomean(BeschaeftigteohneAbschluss_adj, bpu),
            SchulabgaengerohneAbschluss_adj   = weighted.geomean(SchulabgaengerohneAbschluss_adj, bpu)) %>% 
  rename(Gemeindekennziffer = gkz_alt) %>% 
  left_join(., umsteig19, by = c("Gemeindekennziffer" = "gkz_neu")) %>%
  mutate(bev_anteil = Bevoelkerung * bpu) %>% 
  group_by(gkz_alt) %>%
  summarise(Kreis                             = first(Kreis),
            Gemeindeverband                   = first(Gemeindeverband),
            Jahr                              = first(Jahr),
            Bevoelkerung                      = sum(bev_anteil, na.rm = TRUE),
            Beschaeftigtenquote               = weighted.geomean(Beschaeftigtenquote, bpu),
            Arbeitslosigkeit                  = weighted.geomean(Arbeitslosigkeit, bpu),
            Bruttoverdienst_ln                = weighted.mean(Bruttoverdienst_ln, bpu),
            Einkommensteuer_ln                = weighted.mean(Einkommensteuer_ln, bpu),
            Haushaltseinkommen_ln             = weighted.mean(Haushaltseinkommen_ln, bpu),
            Schuldnerquote                    = weighted.geomean(Schuldnerquote, bpu),
            BeschaeftigtemitakadAbschluss_adj = weighted.geomean(BeschaeftigtemitakadAbschluss_adj, bpu),
            BeschaeftigteohneAbschluss_adj    = weighted.geomean(BeschaeftigteohneAbschluss_adj, bpu),
            SchulabgaengerohneAbschluss_adj   = weighted.geomean(SchulabgaengerohneAbschluss_adj, bpu)) %>% 
  rename(Gemeindekennziffer = gkz_alt)

# Jahre wieder zusammenlegen
DataPost2019 <- bind_rows(Daten2020, Daten2021)

# Im Original-Release wurde Amt Creuzburg entfernt, weil es dafür in den alten Rohdaten
# keine Einträge gab. Durch die neuen Rohdaten können wir Amt Creuzburg mitnehmen
amt_czb <- Workfile_full %>% 
  filter(Gemeindekennziffer == 16063104,
         Jahr <= 2019) %>% 
  select(Gemeindekennziffer, Kreis, Gemeindeverband, Jahr, Bevoelkerung,
         Beschaeftigtenquote, Arbeitslosigkeit, Bruttoverdienst_ln, Einkommensteuer_ln,
         Haushaltseinkommen_ln, Schuldnerquote, BeschaeftigtemitakadAbschluss_adj,
         BeschaeftigteohneAbschluss_adj, SchulabgaengerohneAbschluss_adj)

# Amt Creuzburg an den Datensatz anfügen und Datensatz
# exportieren für Weiterverarbeitung im Hauptskript
DataPost2019 <- bind_rows(DataPost2019, amt_czb) %>% 
  arrange(Gemeindekennziffer, Jahr)

saveRDS(DataPost2019, "DataPost2019.rds")

rm(Basedata_Scheibe, Basedata_Scheibe_Gemeindeverbandsebene,
   Basedata_Scheibe_Kreisebene, Daten2020, Daten2021,
   Gemeinden_INKAR_Scheibe, id_dataset_Scheibe, amt_czb,
   umsteig19, umsteig20, umsteig21, Verbraucherpreisindex,
   Workfile_full, Workfile_Scheibe, adj_G8_jahr, OW, weighted.geomean)

